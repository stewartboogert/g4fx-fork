Disclaimer and Legal Information
================================

© 2009–2020 Intel Corporation

[Privacy Notice](https://www.intel.com/privacy)

Intel, the Intel logo, Xeon, Intel Xeon Phi, and Intel Core are
trademarks of Intel Corporation in the U.S. and/or other countries.  
*Other names and brands may be claimed as the property of others.

Performance varies by use, configuration and other factors. Learn more
at
[www.Intel.com/PerformanceIndex](https://www.intel.com/PerformanceIndex).

Intel optimizations, for Intel compilers or other products, may not
optimize to the same degree for non-Intel products.

Intel Embree is using third party libraries in its
implementation. Please see the third-party-programs.txt file contained
in the Embree source and binary distribution for licenses of used
third party components.
