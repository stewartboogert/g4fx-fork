# Code Samples of oneAPI Threading Building Blocks (oneTBB)
This directory contains examples of the `concurrent_priority_queue` container.

| Code sample name | Description
|:--- |:---
| shortpath | Solves the single source shortest path problem using a  `concurrent_priority_queue` container.
