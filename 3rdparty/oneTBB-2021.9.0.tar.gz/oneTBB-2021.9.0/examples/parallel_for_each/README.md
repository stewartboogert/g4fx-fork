# Code Samples of oneAPI Threading Building Blocks (oneTBB)
Examples using `parallel_for_each` algorithm.

| Code sample name | Description
|:--- |:---
| parallel_preorder | Parallel preorder traversal of a graph.
