# Code Samples of oneAPI Threading Building Blocks (oneTBB)
This directory contains examples of the `concurrent_hash_map` container.

| Code sample name | Description
|:--- |:---
| count_strings | Concurrently inserts strings into a `concurrent_hash_map` container.
